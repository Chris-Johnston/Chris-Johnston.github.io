﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using System.Threading.Tasks;

namespace WumpusCombinedBuild
{
    public class HighScore
    {
        // this class stores the high scores
        private string[] placeholderText = {
                                               "Thanks",
                                               "For",
                                               "Playing",
                                               "Team \"Byte Me\"",
                                               "Aaron Ong",
                                               "Chris Johnston",
                                               "Nadia Medvinsky",
                                               "Priya Nakkiran",
                                               "GG",
                                               "WP"
                                           }; // this also serves as credits, two birds with one stone

        private int numberOfScores = 10;

        private List<int> scores = new List<int>();
        private List<string> names = new List<string>();
        private List<int> seeds = new List<int>(); // i realize now that I could have done this with a stack and stored this as it's own object, but it does the job and that's ok.
        // the seeds are actually stored in code, but most of the time no seed is used, and they aren't being displayed on the scoreboard anyways.

        public HighScore()
        {
            Console.WriteLine("Constructed HiScore");
            resetScores();
        }

        /// <summary>
        /// resets the scores to their default values
        /// </summary>
        public void resetScores()
        {
            scores = new List<int>();
            names = new List<string>();
            seeds = new List<int>();
            for (int i = 0; i < numberOfScores; i++)
            {
                scores.Add(i * 10);
                //names.Add("Placeholder " + (i + 1));
                names.Add(placeholderText[numberOfScores - i - 1]);
                seeds.Add(i);
            }
        }

        /// <summary>
        /// adds a new score to the scoreboard and sorts it
        /// </summary>
        /// <param name="num"></param>
        /// <param name="name"></param>
        /// <param name="seed"></param>
        public void addScore(int num, String name, int seed)
        {
            scores.Add(num);
            scores.Sort();
            //int index = scores.FindLastIndex(x => x==num);
            int index = scores.LastIndexOf(num);
            names.Insert(index, name);
            seeds.Insert(index, seed);

            scores.RemoveAt(0);
            names.RemoveAt(0);
            seeds.RemoveAt(0);
        }

        /// <summary>
        /// gets the list of the integer scores
        /// </summary>
        /// <returns></returns>
        public List<int> getScoreInt()
        {
            return scores;
        }

        /// <summary>
        /// gets the list of the score names
        /// </summary>
        /// <returns></returns>
        public List<string> getScoreString()
        {
            return names;
        }

        /// <summary>
        /// gets the list of the seed values
        /// </summary>
        /// <returns></returns>
        public List<int> getSeedInt()
        {
            return seeds;
        }

        /// <summary>
        /// testing method used to print all of the scores, names and seeds
        /// </summary>
        public void printScores()
        {
            for (int i = numberOfScores - 1; i >= 0; i--)
            {
                Console.WriteLine(names[i] + " --- " + scores[i] + " seed: " + seeds[i]);
            }
        }

    }
}
