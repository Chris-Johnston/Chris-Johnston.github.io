﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using System.Threading.Tasks;

namespace WumpusCombinedBuild
{
    public class Player
    {
        // this class stores the player's inventory
        private int NumberOfArrows = 3;  // default value 3
        private int NumberOfCoins = 10; // just in case the player immediately encounters a hazard or wishes to buy something, I'll give them coins so that they can actually play.
        private int NumberOfTurns;
        
        public Player()
        {
            // constructs a new player
            System.Diagnostics.Debug.WriteLine("Constructed Player");
        }

        public override String ToString()
        {
            // returns a string with all the player's characteristics
            return "Player. Arrows: " + NumberOfArrows + " Coins: " + NumberOfCoins + " Turns: " + NumberOfTurns;
        }

        public int getNumberOfTurns()
        {
            // returns the number of turns
            return NumberOfTurns;
        }

        public int getNumberOfCoins()
        {
            // returns the number of coins
            return NumberOfCoins;
        }

        public int getNumberOfArrows()
        {
            // returns the number of arrows ... this should be obvious by now.
            return NumberOfArrows;
        }

        public int getTotalScore()
        {
            // As defined by the packet
            // Score = 100 points - NumberOfTurns + G NumberOfCoins + (10*NumberOfArrows)
            // the 100 points is only if the wumpus is killed.
            // returns the score as int
            return 0 - NumberOfTurns + NumberOfCoins + (10 * NumberOfArrows);
        }

        public void setNumberOfTurns(int turns)
        {
            //user inputs number of turns. Nothing is returned.
            //turns should increment, so myPlayer.setNumberOfTuns(player.getNumberOfTurns + 1) 
                this.NumberOfTurns = turns;

        }

        public void setNumberOfCoins(int coins)
        {
            //user inputs number of coins, nothing is returned.


                this.NumberOfCoins = coins;
        }

        public void setNumberOfArrows(int arrows)
        {
            //user inpus number of arrows, nothing is returned.
                this.NumberOfArrows = arrows;
        }
    }
}
