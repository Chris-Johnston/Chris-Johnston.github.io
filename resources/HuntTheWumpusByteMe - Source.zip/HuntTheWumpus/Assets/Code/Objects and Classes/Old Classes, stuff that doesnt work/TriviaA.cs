﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//using System.IO;

//namespace WumpusCombinedBuild
//{
//    public class TriviaA
//    {
       
//        private bool[] questions = new bool[52];

//        private string[] qLines = System.IO.File.ReadAllLines("test.txt"); //insert where the text file is located in the parenthesis to parse through the lines 

//        Random r = new Random();

//        // returns a string with question and possible answers 

//        public Question obtainQuestion()
//        {
//            //obtains a new question 
//            int n = getFreshQ();
//            //verifies that the question has not been previously asked 
//            questions[n] = true;
//            //gets the question part of question object
//            string question = qLines[n * 8];
//            string[] answers = new string[5];
//            //obtains answer 
//            for (int i = 0; i < answers.Length; i++)
//            {
//                answers[i] = qLines[(n * 8) + i + 1];
//            }
//            //gets the correct answer part of question object
//            string correctStr = qLines[(n * 8) + answers.Length + 1];
//            int correct = Convert.ToInt32(correctStr);
//            //Question q = new Question(question, answers, correct);
//            return q;
//        }

       

//        //finds question, returns question by new number 

//        public int getFreshQ()
//        {
//            int n = r.Next(questions.Length);
//            while (questions[n])
//            {
//                //gets next question if needed
//                n = r.Next(questions.Length);
//            }
//            return n; 
//        }

//    }
//}
