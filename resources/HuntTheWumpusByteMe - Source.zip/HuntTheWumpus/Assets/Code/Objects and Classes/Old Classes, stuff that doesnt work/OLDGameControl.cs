﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//namespace WumpusCombinedBuild
//{
    
//    class GameControl
//    {
//        //private int room = map.getPlayerLocation();
//        private Random gen;
//        private Player player;
//        private Map map;
//        private Cave cave;

//        public GameControl()
//        {
//            System.Diagnostics.Debug.WriteLine("GameControl");
//            //Graphics graphics = new Graphics();

//            gen = new Random();
//            player = new Player();
//            map = new Map(gen);
//            cave = new Cave(gen);

            
//        }
//        public void startGame(){
//            //public void startGame();
//            //Random room = new Random();
//            //if(graphics.startGame()) {
                
//                // send random seed into Trivia object as well when instantiating
//                //cave.generateCells();
//                map.GenerateHazards();
//                map.GeneratePlayerPosition();
//                map.GenerateWumpusPosition();
//                //graphics.generateRoom(cave.getAllConnected(room)); 
                
//            //}
//        }
//        public void viewHighScore()
//        {
//            Console.WriteLine(player.getTotalScore());
//            // send current score from Player object to high score
//            //graphics.displayHighScore();// send int[] of high scores with string array of names into graphics to display
//        }
//        public void moveForward()
//        {
//            int[] roomsToPickFrom = cave.getAllConnected(map.getPlayerLocation());
//            Console.WriteLine("Rooms to pick from:");
//            //Console.WriteLine(String.Join(",",roomsToPickFrom));
//            //graphics.movesForward(true);
//            //graphics should give info about which room was picked based on the button clicked or position moved to
//            //map.setPlayerLocation() put in int returned from graphics
//            // if room number returned matches int from traversed int[] from map.getPitLocation() call fallPit()
//            // else if room number returned matches an int from map.getBatLocation() call bats()
            
      
//            if(map.getHazardsInRoom(map.getPlayerLocation()).Equals("Bat") || map.getHazardsInRoom(map.getPlayerLocation()).Equals("Pit")){
//                //graphics.encountersHazard("pit");
//                askQuestion();
//            }
//        }
//        public void bats()
//        {
//            //graphics.encountersHazard("bats"); 
//            askQuestion();
//        }
//        public void fightWumpus()
//        {
//            if(player.getNumberOfArrows() >=1)
//            {
//                //graphics.fightWumpus();
//                askQuestion();
//                // if the question is answered correctly, subtract from wumpus state or call defeatedWumpus()
//            }

//        }
//        public void askQuestion()
//        {
//            //graphics.displayTrivia(String questions, String [] answers);//get them from trivia
//            // send random seed into Trivia
//            //send String array of q+a to Graphics 
//            // if player buys a hint(returned from Graphics that the player has clicked the icon), call Player to subtract gold, retrieve hint from Trivia and send to Graphics
//            // if player chooses correctly, send to P to up the score 
//            // if wrong deduct from score as needed

//        }
//        public void defeatedWumpus()
//        {
//            //int totalScore = player.getTotalScore();
//            Console.WriteLine(player.getTotalScore());
//            //graphics.gameOver(true, totalScore);
//            // send score into high score method

//        }

//    }
//}

    
     
               

    
        


