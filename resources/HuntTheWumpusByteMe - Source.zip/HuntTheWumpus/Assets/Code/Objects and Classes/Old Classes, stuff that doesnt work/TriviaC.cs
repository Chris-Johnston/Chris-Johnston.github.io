﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
////using System.Threading.Tasks;

//namespace WumpusCombinedBuild
//{
//    public class TriviaC
//    {
//        // this is a incredibly stubbed Triva class. It'd be nice if this was finished and if it worked the same..

//        // 1:18 AM Captain's Log
//        // I just had dinner and I'm still kinda hungry.
//        // Oh yeah we are still missing this class

//        // it's 4/21 and we still don't have this class. how long until I end up doing it myself?

//        private Random gen;

//        public TriviaC(Random g)
//        {
//            gen = g;
//            Console.WriteLine("Constructed");
//            // this should load file
//        }

//        public String getQuestion()
//        {
//            return "How much wood could a wood chuck chuck if a wood chuck could chuck wood?";
//        }

//        public String[] getAnswers()
//        {
//            String[] answers = { "This statement is FALSE!", "Wouldn't you believe that a wood chuck could chuck wood?", "Who cares about the stupid woodchucK?", "asdlkjasdflkjasdf" };
//            return answers;
//        }

//        public Boolean isCorrect(int choice)
//        {
//            int correctAnswer = 2; // this will actually done properly if I end up writing this entire thing. also zero based
//            return choice == correctAnswer;
//        }

//        public void test()
//        {
//            Console.WriteLine(getQuestion());
//            String[] a = getAnswers();
//            foreach (String s in a)
//            {
//                Console.WriteLine("\t" + s);
//            }
//            Console.WriteLine("\nCorrect answer is 3");
//        }

//    }
//}
