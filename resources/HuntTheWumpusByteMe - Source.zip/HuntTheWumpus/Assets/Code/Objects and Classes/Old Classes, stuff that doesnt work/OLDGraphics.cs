﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//namespace WumpusCombinedBuild
//{

//public class Graphics {
//    bool isClicked;
//    private int correctAnswer;
//    public Graphics()
//    {
//        isClicked = true;
//    }

//public void DisplayWallStates(WallStates[] roomWalls)
//{
//    for (int i = 0; i < roomWalls.Length; i++)
//    {
//        Console.WriteLine("Direction: " + (i + 1) + " Angle: " + (i * 60) + " State: " + roomWalls[i]);
//    }
//}
//public void displayTrivia(String question, String[] answers, int correctAnswer)
//{
//    //this.correctAnswer = correctAnswer;
//    //Question.Text = question;
//    //button1.Text = answers[0];
//    //button2.Text = answers[1];
//    //button3.Text = answers[2];
//    //button4.Text = answers[3];
//    Console.WriteLine("This doesn't work");
//    // looks like we are having graphics get the correct answer for simplicity
//    // logic will stay here because why not
    
//}

//private void handleResult(int userAnswer)
//{
//    if (userAnswer == correctAnswer)
//    {
//        Console.Write(true);
//    }
//    else
//    {
//        Console.Write(false);
//    }
//}

 
//}


//}