﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace WumpusCombinedBuild 
{
    public class Question
    {
        // each question's data is stored in one of these objects, contains the question, correct answer and the 3 incorrect answers

        protected string question;
        protected string[] wrongAnswers = new string[3];
        protected string correctAnswer;

        public Question()
        {
            question = "question";
            correctAnswer = "correct";
            for (int i = 0; i < wrongAnswers.Length; i++)
            {
                wrongAnswers[i] = "answer";
            }
        }

        public Question(string q, string c, string[] f)
        {
            question = q;
            correctAnswer = c;
            wrongAnswers = f;
        }

        public String getQuestion()
        {
            return question;
        }
        public string[] getWrong()
        {
            return wrongAnswers;
        }
        public string getCorrect()
        {
            return correctAnswer;
        }

        // used for debug
        public string ToString()
        {
            string str = "";
            str += question;
            foreach (string s in wrongAnswers)
            {
                str += "\n\t" + s;
            }
            str += "\n\t" + correctAnswer;
            return str;
        }
    }
}
