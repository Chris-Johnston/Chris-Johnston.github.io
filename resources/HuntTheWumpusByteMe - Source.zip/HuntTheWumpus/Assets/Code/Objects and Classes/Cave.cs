﻿using UnityEngine;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace WumpusCombinedBuild
{
    public class Cave
    {
        // this class stores all of the Room objects can generate new layouts
       
        private int NUMBER_OF_ROOMS = 30; // to do, see if this is needed
        private int MAX_TUNNELS = 3; // these aren't really needed as I don't plan on changing these... ever.

        private static Room[] myRooms = new Room[30];

        /* defining room layout and direction
         * 1 - Up           0, -2
         * 2 - Up Right Either +1, -1
         * 3 - Down Right +1, +1
         * 4 - Down         0, +2
         * 5 - Down Left +1, -1
         * 6 - Up Left  -1, -1
         * 
         *  I could use enums for this, but it seems a bit more convienient to just use integers
         * 
         * */

        private System.Random generator;

        public Cave(System.Random g)
        {
            myRooms = new Room[NUMBER_OF_ROOMS];

            for (int i = 0; i < myRooms.Length; i++)
            {
                myRooms[i] = new Room();
            }
            //Debug.Log("Constructed Cave");
            generator = g;
        }

        public override String ToString()
        {
            return "Cave";
        }


        /// <summary>
        /// Generates all of the cells in the cave
        /// </summary>
        private void generateCells()
        {
            //split into private helper methods, to make things more readable
            // set all walls to 0, indicating that they havent been set
            for (int i = 0; i < myRooms.Length; i++)
            {
                WallStates[] BlankWalls = new WallStates[6];
                myRooms[i].setWalls(BlankWalls);
            }
            for (int cell = 0; cell < myRooms.Length; cell++)
            {
                WallStates[] currentRoom = myRooms[cell].getWalls();
                int NotSet = 0;
                int Closed = 0;
                int Open = 0;

                for (int w = 0; w < currentRoom.Length; w++)
                {
                    if (currentRoom[w] == WallStates.NotSet)
                    {
                        NotSet++;
                    }
                    else if (currentRoom[w] == WallStates.Closed)
                    {
                        Closed++;
                    }
                    else if (currentRoom[w] == WallStates.Open)
                    {
                        Open++;
                    }
                    else
                    {
                        throw new ArgumentException("There is a problem in generateCells()");
                    }
                }

                int OpenWalls = -1;
                Boolean WallsValid = false;

                do
                {
                    OpenWalls = generator.Next(4);
                    // The wall is OK if and only if
                    // The number of wall generated is less than NotSet
                    // The number of Generated Walls combined with Open is less than or equal to 3
                    // The number of generated walls combined with open is greater than 0

                    WallsValid = OpenWalls <= NotSet && OpenWalls + Open <= MAX_TUNNELS && OpenWalls + Open > 0;

                    if (Open > MAX_TUNNELS || Closed >= 6)
                    {
                        // this fixes a problem with it running forever
                        OpenWalls = 0;
                        WallsValid = true;
                    }

                } while (!WallsValid);

                // Open Walls is the number of walls that will be generated
                // debug int OpenWallsold = OpenWalls;

                while (OpenWalls > 0)
                {
                    int d = generator.Next(6);
                    if (currentRoom[d] == WallStates.NotSet) 
                    {
                        // if random direction in current room is not set
                        currentRoom[d] = WallStates.Open;
                        OpenWalls--;
                    }
                }
                int c = 0;
                for (int i = 0; i < currentRoom.Length; i++)
                {
                    if (currentRoom[i] == WallStates.NotSet)
                    {
                        c++;
                        currentRoom[i] = WallStates.Closed; // close all the remaining walls
                    }
                }

                myRooms[cell].setWalls(currentRoom);

                for (int d = 0; d < 6; d++)
                {

                    int a = getRoomNumDirection(cell, d);
                    int b = inverseDirection(d);
                    myRooms[a].setWall(b, currentRoom[d]); // I know that this can be 1 line, but readability's sake, it's staying like this
                }
            }

            Console.WriteLine("Generated Cave");
        }

        /// <summary>
        /// ensures that each room in the generated cave meets certain requirements
        /// </summary>
        /// <returns></returns>
        private Boolean testValid()
        {
            //Boolean itsAlive = true;
            for (int cell = 0; cell < NUMBER_OF_ROOMS; cell++)
            {
                int closed = 0;
                int open = 0;
                for (int dir = 0; dir < 6; dir++)
                {
                    if (myRooms[cell].getWalls()[dir] == WallStates.Closed)
                    {
                        closed++;
                    }
                    else if (myRooms[cell].getWalls()[dir] == WallStates.Open)
                    {
                        open++;
                    }
                    else
                    {
                        throw new ArgumentException("WallState not set");
                    }
                }

                    //if (open > 3 || closed >= 6)
                if (open > 3)
                {
                    Console.WriteLine("Open > 3");
                    //itsAlive = false;
                    return false;
                    //throw new ArgumentException("Open walls > 3");
                }

                for(int dir = 0; dir < 6; dir++){
                    if (!doWallsMatch(cell, dir))
                    {
                        return false;
                        //throw new ArgumentException("Walls aren't matching");
                        //return false;
                    }
                }
            }
            return true;
            //return itsAlive;
        }
        /// <summary>
        /// ensures that one wall in a certain matches states with it's paired wall
        /// </summary>
        /// <param name="from"></param>
        /// <param name="direction"></param>
        /// <returns></returns>
        private bool doWallsMatch(int from, int direction)
        {
            WallStates fromWall = myRooms[from].getWalls()[direction];
            WallStates toWall = myRooms[getRoomNumDirection(from, direction)].getWalls()[inverseDirection(direction)];

            int toRoom = getRoomNumDirection(from, direction);
            int inverse = inverseDirection(direction);

            return myRooms[from].getWalls()[direction] == myRooms[getRoomNumDirection(from, direction)].getWalls()[inverseDirection(direction)];
        }
        /// <summary>
        /// returns if all the contents in the array are true
        /// </summary>
        /// <param name="a"></param>
        /// <returns></returns>
        private Boolean allValuesTrue(Boolean[] a)
        {
            for (int i = 1; i < a.Length; i++)
            {
                if (!a[i])
                {
                    return false;
                }
            }
            return true;
        }

        private Boolean[] cellStates = new Boolean[30];

        /// <summary>
        /// starts at the first cell and goes through each of the openings until it doesn't have any new places to go to, and then returns true
        /// </summary>
        /// <returns></returns>
        public Boolean goThroughRecursion()
        {
            cellStates = new Boolean[NUMBER_OF_ROOMS];
            goThroughCells(0);
            return allValuesTrue(cellStates);
        }

        public void goThroughCells(int start)
        {
            cellStates[start] = true;
            //Debug.Log("Cell : " + start + " visited.");
            int[] connected = getAllConnected(start);
            for (int i = 0; i < connected.Length; i++)
            {
                if (!cellStates[connected[i]])
                {
                    goThroughCells(connected[i]);
                }
            }
        }

        /// <summary>
        /// generates the cave layout and checks that all the conditions are met
        /// </summary>
        public void Generate()
        {

            Boolean aa = false;
            Boolean bb = false;
            int i = 0;
            do
            {
                aa = false;
                bb = false;
                i++;
                //Debug.Log(i);
                generateCells();
                aa = testValid();

                //Console.WriteLine(aa);

                if (aa)
                {

                    bb = goThroughRecursion();

                    // OH MY GOD SO MUCH FASTER

                    //Console.WriteLine("b " + bb);
                }

                //Console.WriteLine(canVisitAllCells());


            } while (!(aa && bb));
            Debug.Log("Cave is good after " + i + " tries");
        }

        /// <summary>
        /// gets the int of the opposite direction
        /// </summary>
        /// <param name="dir"></param>
        /// <returns></returns>
        private int inverseDirection(int dir)
        {
            switch (dir)
            { // I should switch this to enums
                case 0:
                    return 3;
                case 1:
                    return 4;
                case 2:
                    return 5;
                case 3:
                    return 0;
                case 4:
                    return 1;
                case 5:
                    return 2;

                default:
                    return 0;
            }
        }
        /// <summary>
        /// returns the room number of the room 1 cell away in a specified direction
        /// </summary>
        /// <param name="RoomNum"></param>
        /// <param name="dir"></param>
        /// <returns></returns>
        public int getRoomNumDirection(int RoomNum, int dir)
        {
            return getAllSurrounding(RoomNum)[dir];
        }

        /// <summary>
        /// gets the room from the given x/y coordinates
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <returns></returns>
        public Room getRoom(int x, int y)
        {
            int roomNum = CoordsToRoom(x, y);

            return myRooms[roomNum];
        }
        
        /// <summary>
        /// gets the room from the given array of x, y coordinates
        /// </summary>
        /// <param name="coords"></param>
        /// <returns></returns>
        public Room getRoom(int[] coords)
        {
            int roomNum = CoordsToRoom(coords);
            return myRooms[roomNum];
        }

        /// <summary>
        /// gets the Room from the list of rooms in the cave
        /// </summary>
        /// <param name="roomNum"></param>
        /// <returns></returns>
        public Room getRoom(int roomNum)
        {
            return myRooms[roomNum];
        }

        // set these back to private after testing
        private int CoordsToRoom(int x, int y)
        {
            // This took far longer than I'd like to admit to figure out.
            // Returns the room # given the x y coordinates
            return (x + 1 + (y / 2 * 6)) - 1;
        }

        /// <summary>
        /// zero based, gets the room based on coordinates
        /// </summary>
        /// <param name="coords"></param>
        /// <returns>room number</returns>
        private int CoordsToRoom(int[] coords)
        {

            // returns the room # given an array containing {x, y} coordinates.
            //return (coords[0] + 1 + (coords[1] / 2 * 6)); 
            return (coords[0] + 1 + (coords[1] / 2 * 6)) - 1;
        }

        /// <summary>
        ///  gets the x coordinate of the current room
        /// </summary>
        /// <param name="room"></param>
        /// <returns></returns>
        private int RoomToX(int room)
        {
            // returns the x value of the room #
            return ((room) % 6); // (room - 1)
        }

        /// <summary>
        /// gets the y coordinate of the current room
        /// </summary>
        /// <param name="room"></param>
        /// <returns></returns>
        private int RoomToY(int room)
        {
            // returns the y value of the room #
            // this also took really long
            int y = (room) / 6 * 2; // (room - 1)
            if (RoomToX(room) % 2 == 1) // == 1
            {
                y += 1;
            }
            return y;
        }

        /// <summary>
        /// gets all the connected and accessable rooms from the one given
        /// </summary>
        /// <param name="room"></param>
        /// <returns></returns>
        public int[] getAllConnected(int room)
        {
            // This should get all rooms that are connected to each other
            List<int> connected = new List<int>();

            int[] surrounding = getAllSurrounding(room);

            for (int i = 0; i < surrounding.Length; i++)
            {
                if (myRooms[room].getWalls()[i] == WallStates.Open)
                {
                    connected.Add(surrounding[i]);
                }
            }

            return connected.ToArray();
        }

        /// <summary>
        /// gets all of the surrounding rooms from the one given
        /// </summary>
        /// <param name="room"></param>
        /// <returns></returns>
        public int[] getAllSurrounding(int room)
        {
            // This should get all rooms that surround the room
            int x = RoomToX(room);
            int y = RoomToY(room);
            int[] surrounding = { CoordsToRoom(ValidateRoom(x, y - 2)), CoordsToRoom(ValidateRoom(x + 1, y - 1)), CoordsToRoom(ValidateRoom(x + 1, y + 1)), CoordsToRoom(ValidateRoom(x, y + 2)), CoordsToRoom(ValidateRoom(x - 1, y + 1)), CoordsToRoom(ValidateRoom(x - 1, y - 1)) };
            return surrounding;
        }

        /// <summary>
        /// returns the coordinates of a room, and allows the rooms to wrap around properly
        /// </summary>
        /// <param name="coord"></param>
        /// <returns></returns>
        private int[] ValidateRoom(int[] coord)
        {
            // returns an int[] of a room after validating coordinates. This solves the problem of wrapping around levels.
            // coordinates should be in format {x, y}
            if (coord[0] > 5)
            {
                coord[0] -= 6; // this can only be one value.
            }
            else if (coord[0] < 0)
            {
                coord[0] += 5;

            }

            if (coord[1] > 9)
            {
                coord[1] -= 10; // this could result in either 0 or 1
            }
            else if (coord[1] < 0)
            {
                coord[1] += 10;
            }

            return coord;
        }

        private int[] ValidateRoom(int x, int y)
        {
            int[] coord = { x, y };

            if (coord[0] > 5)
            {
                coord[0] -= 6;
            }
            else if (coord[0] < 0)
            {
                coord[0] += 6;
            }

            if (coord[1] > 9)
            {
                coord[1] -= 10;
            }
            else if (coord[1] < 0)
            {
                coord[1] += 10;
            }

            return coord;
        }
    }
}
