﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WumpusCombinedBuild
{
    public class Map
    { 
        // this class stores the locatios of hazards and the player
        private int PlayerLocation = -1; // room # of player
        private int WumpusLocation = -1; // room # of Wumpus
        private String WumpusState = "Not Set"; // State of Wumpus. this actually isn't being used.

        private int NumberOfBats = 2; // this could be a constant defined in GameControllerUnity
        private int NumberOfPits = 2;

        private int[] PitLocation; // Array of pit locations
        private int[] BatLocation; // Array of bat locations

        public enum Hazards {Nothing, Bat, Pit, Wumpus}; // defines the type of hazards that can be encountered in each room  

        private Random generator;

        public Map(Random generator, int NumberOfBats, int NumberOfPits)
        {
            // constructs a new map
            // requires a Random object as a parameter
            this.generator = generator;
            this.NumberOfBats = NumberOfBats;
            this.NumberOfPits = NumberOfPits;
            System.Diagnostics.Debug.WriteLine("Constructed Map with Bats: " + NumberOfBats + " Pits: " + NumberOfPits);

            PitLocation = new int[NumberOfPits];
            BatLocation = new int[NumberOfBats];
        }

        public Map(Random generator)
        {
            // requires a Random object as a parameter
            this.generator = generator;
            System.Diagnostics.Debug.WriteLine("Constructed Map with Bats: " + NumberOfBats + " Pits: " + NumberOfPits);
            PitLocation = new int[NumberOfPits];
            BatLocation = new int[NumberOfBats];
        }

        ///// <summary>
        ///// generates a secret
        ///// </summary>
        ///// <param name="connectedRooms"></param>
        ///// <returns></returns>
        //public String getSecret(int[] connectedRooms)
        //{
        //    // this is when you purchase a secret..
        //    int numberPossible = 4;

        //    String possible = "Maybe the Wumpus is in: "; // i kinda stole this mechanic from another game that I made this year but who cares.

        //    int rand = generator.Next(4);

        //    for (int i = 0; i < numberPossible; i++)
        //    {
        //        if (i == rand)
        //        {
        //            possible += WumpusLocation + " ";
        //        }
        //        else
        //        {
        //            possible += generator.Next(30) + " "; // if these happen to match up... ehhh I consider it lucky RNG for the player
        //        }
        //    }

        //    return possible;
        //}

        /// <summary>
        /// generates the position for the escaping Wumpus
        /// </summary>
        /// <param name="wumpusConnectedRooms"></param>
        public void escapingWumpus(int[] wumpusConnectedRooms)
        {
            // picks a random room for the wumpus that is safe, if there is nowhere to go, the wumpus doesn't move, this can be repeated twice

            int direction;
            int toRoom;

            if (wumpusConnectedRooms.Length < 2)
            {
                // if theres only 1 or 0 exits, don't go anywhere, the wumpus is cornered
                return;
            }

            do
            {
                direction = generator.Next(wumpusConnectedRooms.Length);
                toRoom = wumpusConnectedRooms[direction];
            } while (toRoom == PlayerLocation);

            WumpusLocation = toRoom;

        }

        /// <summary>
        /// returns the hazards that are in a given room
        /// </summary>
        /// <param name="room"></param>
        /// <returns></returns>
        public Hazards getHazardsInRoom(int room)
        {// todo convert this over to use Hazards enum instead of String.
            if (WumpusLocation == room)
            {
                return Hazards.Wumpus;
            }
            foreach (int i in PitLocation)
            {
                if (i == room)
                {
                    return Hazards.Pit;
                    //return "Pit";
                }
            }
            foreach (int i in BatLocation)
            {
                if (i == room)
                {
                    return Hazards.Bat;
                }
            }            
            return Hazards.Nothing;
        }

        public override String ToString()
        {
            // returns Map information as String.
            return "Map. Player Location: " + PlayerLocation + " Wumpus Location: " + WumpusLocation + " Wumpus State: " + WumpusState;
        }

        /// <summary>
        /// generates hazards
        /// </summary>
        public void GenerateHazards()
        {
            // Generates random loocations for Bats, Pits
            GenerateBats();
            GeneratePits();            
        }

        /// <summary>
        /// generates the positions for bats
        /// </summary>
        public void GenerateBats()
        {
            for (int i = 0; i < NumberOfBats; i++)
            {
                BatLocation[i] = GetSafeRoom();
            }
        }

        /// <summary>
        /// generates position for pits
        /// </summary>
        public void GeneratePits()
        {
            for (int i = 0; i < NumberOfPits; i++)
            {
                PitLocation[i] = GetSafeRoom();
            }
        }

        /// <summary>
        /// generates position for player, makes sure that the room is safe
        /// </summary>
        public void GeneratePlayerPosition()
        {  
            // Generates random location for Player
            do
            {
                PlayerLocation = GetSafeRoom();
            } while (PlayerLocation == WumpusLocation);
        }

        /// <summary>
        /// generates the Wumpus position, in a safe room
        /// </summary>
        public void GenerateWumpusPosition()
        {
            // Generates random location for Wumpus.
            do
            {
                WumpusLocation = GetSafeRoom();
            } while (WumpusLocation == PlayerLocation);
        }

        /// <summary>
        /// returns a safe room, randomly generated
        /// </summary>
        /// <returns></returns>
        private int GetSafeRoom()
        {
            // returns a room that doesn't contain hazards
            int room;
            Boolean RoomSafe = true;
            do
            {
                RoomSafe = true;
                room = generator.Next(30);
                               
                for (int i = 0; i < BatLocation.Length; i++)
                {
                    if (room == BatLocation[i])
                    {
                        RoomSafe = false;
                    }
                }
                
                for (int i = 0; i < PitLocation.Length; i++)
                {
                    if (room == PitLocation[i])
                    {
                        RoomSafe = false;
                    }
                }

            } while (!RoomSafe);

            return room;
        }

        public int getNumberOfBats()
        {
            // returns the number of bats
            return NumberOfBats;
        }

        public int getNumberOfPits()
        {
            // returns the number of pits
            // Both of these values should not be set after generation, otherwise it would screw everything up.
            return NumberOfPits;
        }

        public int getPlayerLocation()
        {
            // returns the player location
            return PlayerLocation;
        }

        public void setPlayerLocation(int pos)
        {
            // sets the player location only if the position is valid.
            if (isPositionValid(pos))
            {
                this.PlayerLocation = pos;
            }
            else
            {
                // DEBUG
                System.Console.WriteLine("Player Location Invalid");
            }
            // validation of moves should be done by gamemanager and also the cave object
        }

        public int getWumpusLocation()
        {
            // returns the wumpus location
            return WumpusLocation;
        }

        public void setWumpusLocation(int pos)
        {
            // sets the location of the wumpus only if the position is valid
            if (isPositionValid(pos))
            {
                this.WumpusLocation = pos;
            }
            else
            {
                // DEBUG
                System.Console.WriteLine("Wumpus Location Invalid");
            }
            // validation of moves should be done by gamemanager and also the cave object
        }

        public String getWumpusState()
        {
            // returns the state of the wumpus
            return WumpusState;
        }

        public void setWumpusState(String state)
        {
            // sets the state of the wumpus
            this.WumpusState = state;
        }

        public int[] getPitLocation()
        {
            // returns the array of pit locations
            return PitLocation;
        }

        public void setPitLocation(int[] loc)
        {
            // sets the array of pit locations
            if (isPositionValid(loc))
            {
                this.PitLocation = loc;
            }
            else
            {
                System.Diagnostics.Debug.WriteLine("Pit Location Invalid");
            }
        }

        public int[] getBatLocation()
        {
            // gets the array of bat locations
            return BatLocation;
        }

        public void setBatLocation(int[] loc)
        {
            // sets the array of pit locations
            if (isPositionValid(loc))
            {
                this.BatLocation = loc;
            }
            else
            {
                // DEBUG
                System.Diagnostics.Debug.WriteLine("Bat Location Invalid");
            }
        }

        private Boolean isPositionValid(int position)
        {
            // returns if the position is valid.
            return (position > 30 || position <= 0);
        }

        private Boolean isPositionValid(int[] position)
        {
            // returns if the array of positions is valid.
            for (int i = 0; i < position.Length; i++)
            {
                if (position[i] > 30 || position[i] <= 0)
                {
                    return false;
                }

            }
            return true;
        }
    }
}
