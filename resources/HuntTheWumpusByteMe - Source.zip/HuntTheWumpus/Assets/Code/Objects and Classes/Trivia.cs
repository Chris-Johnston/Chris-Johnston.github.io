﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.IO;
using UnityEngine;

namespace WumpusCombinedBuild
{
    public class Trivia
    {
        // this class stores all of the questions and handles questions being asked.
        private System.Random gen;
        private List<Question> questions = new List<Question>();
        private bool[] used;
        private string xmlContent;

        private int currentQuestion = 0;
        private int correctAns;

        public Trivia(System.Random g, string fileContents)
        {
            gen = g;
            xmlContent = fileContents;
        }

        public void setUpTrivia()
        {
            parseXML();
            used = new bool[questions.Count];
        }

        public void pickQuestion()
        {
            if (allTrue(used))
            {
                used = new bool[questions.Count];
                Console.WriteLine("Ran out of questions, will now restart from beginning");
            }

            while (used[currentQuestion])
            {
                currentQuestion = gen.Next(questions.Count);
            }

            used[currentQuestion] = true;
        }

        public String ToString()
        {
            return questions[currentQuestion].ToString();
        }

        private bool allTrue(bool[] b)
        {
            foreach (bool i in b)
            {
                if (!i)
                {
                    return false;
                }
            }
            return true;
        }

        public string getQuestion()
        {
            return questions[currentQuestion].getQuestion();
        }

        public string[] getAnswers()
        {
            List<string> q = questions[currentQuestion].getWrong().ToList(); // at this point I should just be using Lists.. obviously superior in every way.
            var shuffle = q.OrderBy(item => gen.Next()); // thanks stackoverflow
            correctAns = gen.Next(4);
            q.Insert(correctAns, questions[currentQuestion].getCorrect());
            return q.ToArray();
        }

        public bool isCorrect(int answer)
        {
            return correctAns == answer;
        }

        private void test()
        {
            pickQuestion();
            Console.WriteLine(getQuestion());
            string[] ans = getAnswers();

            foreach (string a in ans)
            {
                Console.WriteLine("\t" + a);
            }

            Console.WriteLine(isCorrect(1));
        }

        private void parseXML(){
            //XmlDocument trivia = new XmlDocument();
            //trivia.Load(triviaFileLocation);
            // this doesn't work in the web build. I'll get on it... eventually.
            
            // luckily Unity can handle reading files, so we just have to get the data and parse it
            XmlDocument trivia = new XmlDocument();
            trivia.LoadXml(xmlContent);

            foreach (XmlNode question in trivia.DocumentElement)
            {
                string q = "";
                string c = "";
                List<string> f = new List<string>();

                foreach (XmlNode n in question.ChildNodes)
                {
                    switch (n.Name)
                        {
                            case "q":
                                q = n.InnerText;
                                break;
                            case "c":
                                c = n.InnerText;
                                break;
                            case "f":
                                f.Add(n.InnerText);
                                break;
                            default:
                                break;
                                //throw new System.ArgumentException("XML document contained invalid node");
                                // this would freak out if it encountered XML comments <!-- so I'll just leave it alone
                        }
                }
                questions.Add(new Question(q, c, f.ToArray()));
                
            }

        }
    }
}
