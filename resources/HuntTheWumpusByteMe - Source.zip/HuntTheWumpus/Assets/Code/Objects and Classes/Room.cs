﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using System.Threading.Tasks;

namespace WumpusCombinedBuild
{
    public enum WallStates { NotSet, Closed, Open };
    public enum Directions { Up, UpRight, DownRight, Down, DownLeft, UpLeft };

    public class Room
    {
        // this object stores all 6 of the room'ms wall states
        // I planned on making different "themed" rooms, that each have a unique style to them, but there wasn't quite enough time to get that done
        
        private WallStates[] DoorStates = new WallStates[6];
        
        public Room(WallStates[] States)
        {
            DoorStates = States;

        }

        public Room()
        {
            DoorStates = new WallStates[6];
        }

        public WallStates[] getWalls()
        {
            return DoorStates;
        }

        public void setWalls(WallStates[] States)
        {
            DoorStates = States;
        }
        public void setWall(int dir, WallStates state)
        {
            DoorStates[dir] = state;
        }
        public void setWall(Directions dir, WallStates state)
        {
            DoorStates[(int)dir] = state;
        }
    }
}
