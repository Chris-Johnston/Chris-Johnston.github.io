﻿using UnityEngine;
using UnityEngine.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WumpusCombinedBuild
{
    public class GameControllerUnity : MonoBehaviour
    {
        // this class stores the objects that are used in multiple other classes and has methods that are used globally
        public static int RandomSeed = -1; // 1337 is the testing seed because 1337
        public static System.Random gen;

        public static Cave myCave;
        public static Map myMap;
        public static Player myPlayer;
        public static Trivia myTrivia;
        public static HighScore myScores;
        public static String playerName = "Default Name"; // this will be set at the end of the game, not at the start of the game
        public static string triviaFileContents = "error"; // this will get parsed in Trivia.cs

        public void Start(){

            //Debug.Log(triviaF.text);
            //triviaFile = (TextAsset)Resources.Load("Trivia");
            // this is called when Unity loads the GameObject with this script, we need it
            DontDestroyOnLoad(this.gameObject.transform); // prevents the game controller from being destroyed when a new scene is loaded
        }

        /// <summary>
        /// sets the seed for the System.Random object
        /// </summary>
        /// <param name="p"></param>
        public void setSeed(String p)
        {
            bool parser = int.TryParse(p, out RandomSeed);
            if (!parser)
            {
                // should the parser fail,
                RandomSeed = -1;
                gen = new System.Random();
            }
            else
            {
                gen = new System.Random(RandomSeed);
            }
        }
        
        /// <summary>
        /// constructs new objects, excluding ones that need to be preserved between games
        /// </summary>
        public void ConstructEverything(){

            if (RandomSeed == -1)
            {
                gen = new System.Random(); // no seed
            }
            else
            {
                gen = new System.Random(RandomSeed);
            }
            myMap = new Map(gen);
            myPlayer = new Player();
            myTrivia = new Trivia(gen, triviaFileContents);

            if (myScores == null)
            {
                myScores = new HighScore(); // if there is one already, it should be kept as scores should save across different playthroughs
            }
        }

        public GameControllerUnity(){
            ConstructEverything();
        }
        

        // these next methods are used to switch between unity scenes
        public void titleScreen()
        {
            Debug.Log("Title Screen");
            Application.LoadLevel("TitleScreen");
        }
        public static void titleS()
        {
            Application.LoadLevel("TitleScreen");
        }

        public static void pickC()
        {
            Debug.Log("Pick Cave");
            Application.LoadLevel("PickCave");
        }

        public void pickCave()
        {
            DontDestroyOnLoad(gameObject.transform);
            Debug.Log("Pick Cave");
            Application.LoadLevel("PickCave");
        }

        public static void startG()
        {
            Application.LoadLevel("MainGame");
        }

        public void startGame()
        {
            ConstructEverything();
            Debug.Log("Start Game");
            Application.LoadLevel("MainGame"); 
        }

        // I have duplicate methods for use in unity and use in code
        public static void viewHS()
        {
            Debug.Log("View High Scores");
            Application.LoadLevel("HiScores");
        }

        public void viewHighScores()
        {
            Debug.Log("View High Scores");
            Application.LoadLevel("HiScores");
        }

        public void quitGame()
        {
            Debug.Log("Quit");
            Application.Quit();

        }
    }

}
