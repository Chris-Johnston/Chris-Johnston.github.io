﻿using UnityEngine;
using UnityEngine.UI;
using System;
using System.Collections;
using System.Collections.Generic;

namespace WumpusCombinedBuild
{
    public class ShowPickCave : MonoBehaviour
    {
        // this code is used to manage the "Pick Cave" scene, as well as set the seed

        public GameObject hexFloor;
        public GameObject linePrefab;
        public GameObject parentObject;
        public Text labelText;

        private GameObject previewCave;
        public static int selectedCave = 0;

        private Vector3 viewPosition = new Vector3(-33, 25, 50);

        private int tempSeed = -1;

        private List<GameObject> myCaveLayouts = new List<GameObject>();
        private static List<Cave> myCaves = new List<Cave>();
        public static Cave pickedCave;

        void makeLines(GameObject parent, Room thisRoom)
        {
            GameObject lineDraw;
            WallStates[] states = thisRoom.getWalls();

            for (int i = 0; i < states.Length; i++)
            {
                if (states[i] == WallStates.Open)
                {
                    lineDraw = Instantiate(linePrefab);
                    lineDraw.transform.parent = parent.transform;
                    lineDraw.transform.position = parent.transform.position;
                    lineDraw.name = "Line: " + i;
                    lineDraw.transform.rotation = Quaternion.AngleAxis(210 - 30 - i * 60, Vector3.up);
                }
            }
            
        }

        public void setSeed(InputField userField)
        {
            string p = userField.text;
            bool parser = int.TryParse(p, out GameControllerUnity.RandomSeed);
            if (!parser)
            {
                // should the parser fail,
                GameControllerUnity.RandomSeed = -1;
                tempSeed = -1; // this should make a new random object when the generate button is hit, otherwise it won't even apply.... todo
                //Debug.Log("Seed random");
                GameControllerUnity.gen = new System.Random();
            }
            else
            {
                //Debug.Log("Seed: " + GameControllerUnity.RandomSeed);
                GameControllerUnity.gen = new System.Random(GameControllerUnity.RandomSeed);
            }
        }

        public void display()
        {
            float timeStart = Time.time;
            myCaveLayouts = new List<GameObject>();
            
            foreach (Transform child in parentObject.gameObject.transform)
            {
                GameObject.Destroy(child.gameObject);
            }

            Debug.Log("Generating Caves");
            generateAllCaves();
            Debug.Log("Make Cave Parent");
            makeCaveParent();
            Debug.Log("Displaying");

            for (int f = 0; f < 5; f++)
            {
                myCaveLayouts[f].transform.position = new Vector3(-35 + (f * 10), -20, 20);
                myCaveLayouts[f].transform.localScale = new Vector3(0.2f, 0.2f, -0.2f);
                myCaveLayouts[f].transform.rotation = Quaternion.AngleAxis(-90, Vector3.right);
            }

            labelText.text = "Cave: 1";

            if (previewCave != null)
            {
                // previewCave has already been made
                GameObject.Destroy(previewCave);
            }

            previewCave = Instantiate(myCaveLayouts[selectedCave]);
            previewCave.transform.position = viewPosition;
            previewCave.transform.localScale = new Vector3(1, 1, -1);
            Debug.Log("DONE");
            Debug.Log("Time: " + (Time.time - timeStart));
        }

        // Use this for initialization
        public void Start()
        {
            // used for testing
            if (GameControllerUnity.gen == null)
            {
                GameControllerUnity.gen = new System.Random();
            }

            display();
            pickCave(0); // Defaults to this
        }

        void makeCaveParent()
        {
            for (int i = 0; i < 5; i++)
            {
                Cave currentCave = myCaves[i];
                currentCave.Generate();
                // create 5 different grids of caves
                //myCaveLayouts.Add(new GameObject());
                GameObject CurrentCaveLayout = new GameObject();
                
                CurrentCaveLayout.name = "Parent " + i;
                CurrentCaveLayout.transform.parent = parentObject.transform;
                CurrentCaveLayout.transform.position = new Vector3(0, 0, 0);

                Debug.Log("Creating Cave " + i);

                int c = 0;

                for (int row = 0; row < 5; row++)
                {
                    //Debug.Log("Row " + row);
                    GameObject myCave;

                    for (int x = 0; x < 3; x++)
                    {

                        //Debug.Log("X: " + x);
                        myCave = CurrentCaveLayout.transform.parent.gameObject;
                        myCave = Instantiate(hexFloor);
                        myCave.gameObject.transform.parent = CurrentCaveLayout.gameObject.transform;
                        myCave.transform.position = new Vector3((x * 14.0f), 0, (8 * row));
                        //Debug.Log("I: " + i + " C: " + c);
                        makeLines(myCave.gameObject, currentCave.getRoom(c));
                        c++;
                        myCave.name = "Tile: " + c + "x: " + x + " row: " + row + " set " + i;

                        myCave.gameObject.GetComponentInChildren<Text>().text = "" + c;

                        myCave = CurrentCaveLayout.transform.parent.gameObject;
                        myCave = Instantiate(hexFloor);
                        myCave.gameObject.transform.parent = CurrentCaveLayout.gameObject.transform;
                        myCave.transform.position = new Vector3(7.0f + (x * 14.0f), 0, 4.0f + (8 * row));
                        //Debug.Log("I: " + i + " C: " + c);
                        makeLines(myCave.gameObject, currentCave.getRoom(c));
                        c++;
                        myCave.name = "Tile: " + c + "x: " + x + " row: " + row + " set " + i + " offset";

                        myCave.gameObject.GetComponentInChildren<Text>().text = "" + c;
                        //System.Console.WriteLine("Breakpoint");
                        //Debug.Log("Plz work");
                    }
                }

                CurrentCaveLayout.transform.position = new Vector3(i * 50, 0, 0);
                Transform myTransform = CurrentCaveLayout.transform;
                myTransform.localScale += new Vector3(0, 0, -2);
                myCaveLayouts.Add(CurrentCaveLayout);
            }
        }

        public void generateAllCaves()
        {
            myCaves = new List<Cave>();
            for (int i = 0; i < 5; i++)
            {
                myCaves.Add(new Cave(GameControllerUnity.gen));
            }
        }

        private DateTime debounce = DateTime.Now;
        // Update is called once per frame, not needed.
        void Update()
        {
            if (DateTime.Now.Second - debounce.Second > 0.2f)
            {
                if (Input.GetAxis("Start") > 0.5f)
                {
                    selectCave();
                }
                else if (Input.GetAxis("FireArrow") > 0.5f)
                {
                    display();
                }
            }
        }

        public void pickCave(int num)
        {
            selectedCave = num;
            labelText.text = "Cave: " + (selectedCave + 1);
            Destroy(previewCave.gameObject);
            previewCave = Instantiate(myCaveLayouts[selectedCave]);
            previewCave.transform.position = viewPosition;
            previewCave.transform.localScale = new Vector3(1, 1, -1);
            pickedCave = myCaves[selectedCave];
        }

        public void selectCave()
        {
            GameControllerUnity.myCave = pickedCave;
            GameControllerUnity.startG();
        }
    }
}
