﻿using UnityEngine;
using System.Collections;

public class HelpScreen : MonoBehaviour {

    // this class handles the help screen overlay, it's pretty basic.

    public GameObject HelpCanvas;

    public void toggleHelp()
    {
        HelpCanvas.active = !HelpCanvas.active;
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.F1))
        {
            toggleHelp();
        }
    }
}
