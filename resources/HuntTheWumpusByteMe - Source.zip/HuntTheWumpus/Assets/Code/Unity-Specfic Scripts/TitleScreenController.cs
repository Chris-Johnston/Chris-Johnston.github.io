﻿using UnityEngine;
using UnityEngine.UI;
using System;
using System.Collections;
using System.Collections.Generic;


namespace WumpusCombinedBuild
{
    public class TitleScreenController : MonoBehaviour
    {

        // All that this script does is add the animations to some of the objects when the game starts. It's purley cosmetic and for the title screen only.

        public GameObject titleCanvas;
        public GameObject demoCaveParent;
        public GameObject title;
        

        //public Animation titleDrop;
        //public Animation titleDropButton;

        // Use this for initialization
        void Start()
        {
            //DontDestroyOnLoad(this.gameObject.transform);
            //Debug.Log("Pick Cave");
            //Application.LoadLevel(1);
        }
        // Update is called once per frame
        void Update()
        {
            
                if (Input.GetAxis("Start") > 0.5f || Input.GetKeyDown(KeyCode.Return))
                {
                    GameControllerUnity.pickC();
                }
                else if (Input.GetAxis("B1") > 0.5f)
                {
                    GameControllerUnity.viewHS();
                } // no quit button because it's not needed to demo
     
            // to do, change this so that it uses an animation based system instead of time-based math
            if (Time.time > 0.25f)
            {
                titleCanvas.transform.rotation = Quaternion.AngleAxis(Mathf.Sin((Time.time - 2.0f) * 1.5f) * 7.0f, Vector3.up);
                demoCaveParent.transform.Rotate(new Vector3(0, 15 * Time.deltaTime, 0));
            }
            


        }
    }
}


