﻿using UnityEngine;
using System;
using UnityEngine.UI;
using System.Collections;

namespace WumpusCombinedBuild
{
    public class InGameController : MonoBehaviour
    {
        // this is the BIG one.
        // this handles basically everything that hasn't been done yet
        /* displaying the cave
         * moving about the cave
         * all of the GUI
         * displaying and answering trivia
         * encountering hazards
         * submitting scores
         * game over
         * sounds
         * input
         * */

        // most of these public objects are used so that I can refer to an object in the Unity editor in code
        public GameObject RoomParent;

        public GameObject mainCamera;
        private Animator cameraAnimator;
        private Animator roomAnimator;

        public GameObject templateFloor;
        public GameObject templateWall;
        public GameObject templateDoor;
        public GameObject templatePit;
        public GameObject templatePlank;

        public GameObject WumpusObject;
        public GameObject BatObject;
        private Animator BatAnim;
        public GameObject ArrowObject;

        public TextAsset triviaFile;

        public Text GUIArrows;
        public Text GUICoins;
        public Text GUITurns;

        public GameObject onScreenControls;
        public GameObject triviaCanvas;
        public GameObject gameOverCanvas;
        public Text gameOverReason;

        public GameObject hintCanvas;
        public Text hintText;

        public GameObject CorrectText;
        public GameObject IncorrectText;

        public Image gameOverColor;
        public Text gameOverScore;
        
        public AudioSource ArrowSound;
        public AudioSource CoinSound;
        public AudioSource WumpusSound;
        public AudioSource BatSound;
        public AudioSource StepSound;
        public AudioSource WindSound;

        public GameObject fromArrowPrefab;

        //public GameObject arrow;
        public Text infoText;
        private GameObject fromArrow;

        private int room = 0;
        private int direction = 0;
        private WallStates[] walls;

        private bool inTrivia = false;
        private bool hasTriviaRemaining = false;
        private bool buyMenuActive = false;
        private bool canMove = true;
        public GameObject buyMenu;

        // Use this for initialization
        void Start()
        {

            BatAnim = BatObject.GetComponent<Animator>();
            toDir = direction;
            cameraAnimator = mainCamera.GetComponent<Animator>();
            roomAnimator = RoomParent.GetComponent<Animator>();

            GameControllerUnity.triviaFileContents = triviaFile.text;
            GameControllerUnity.myTrivia = new Trivia(GameControllerUnity.gen, GameControllerUnity.triviaFileContents);
            GameControllerUnity.myTrivia.setUpTrivia();

            gameOverReason.text = "";
            
            GameControllerUnity.myMap.GenerateWumpusPosition();
            GameControllerUnity.myMap.GenerateHazards();
            GameControllerUnity.myMap.GeneratePlayerPosition();
            GameControllerUnity.myMap.setPlayerLocation(0);
            room = GameControllerUnity.myMap.getPlayerLocation();

            destroyRoom();
            createRoom();
        }

        private DateTime onScreenTimer;
        public int onScreenLength = 3; // how many seconds to display the thing on screen

        /// <summary>
        /// displays the string on a panel shown on screen
        /// </summary>
        /// <param name="s"></param>
        public void showOnScreen(string s)
        {
            Debug.Log(s);
            onScreenTimer = DateTime.Now;
            hintText.text = s;
            hintCanvas.SetActive(true);
            // play animations
        }
        
        /// <summary>
        /// destroys the current room
        /// </summary>
        public void destroyRoom()
        {
            WumpusObject.SetActive(false);
            BatObject.SetActive(false);
            ArrowObject.SetActive(false);
            foreach (Transform c in RoomParent.transform)
            {
                GameObject.Destroy(c.gameObject);
            }
            GameObject.Destroy(fromArrow);
        }


        /// <summary>
        /// creates the current room
        /// </summary>
        public void createRoom()
        {

            // first set up the room's parent so that the model's hiearchy is nice and neat
            RoomParent.transform.position = Vector3.zero;
            RoomParent.transform.localScale = Vector3.one;
            RoomParent.transform.rotation = Quaternion.EulerAngles(Vector3.zero);

            // get the current room and walls for this room
            Room thisRoom = GameControllerUnity.myCave.getRoom(room);
            walls = thisRoom.getWalls();

            int d = 0;
            GameObject floorObj; // make a parent for the floor
            bool isPit = GameControllerUnity.myMap.getHazardsInRoom(room) == Map.Hazards.Pit;
            if (isPit) // check if the current room has a pit
            {
                floorObj = Instantiate(templatePit);
            }
            else
            {
                floorObj = Instantiate(templateFloor); // this spawns in either a pit or a regular floor based on what's in this room
            }

            foreach (WallStates s in walls)
            { // for each direction
                GameObject newObj;
                GameObject newPlank;
                
                if (s == WallStates.Open) // if it's open, make an open door
                {
                    newObj = Instantiate(templateDoor);
                    newObj.name = "Open Door";

                    if (isPit) // if there is a pit, create those planks that connect from the door to the pit
                    {
                        newPlank = Instantiate(templatePlank);
                        newPlank.name = "Plank for the pit";
                        newPlank.transform.parent = newObj.transform;
                        newPlank.transform.localRotation = Quaternion.AngleAxis(180, Vector3.up); // don't fiddle with this
                        newPlank.transform.localPosition = new Vector3(0, 1, 0);
                        newPlank.transform.localScale = new Vector3(0.5f, 0.5f, 0.5f);
                    }

                }
                else
                {
                    newObj = Instantiate(templateWall);
                    newObj.name = "Closed Wall"; // create a boring, normal closed wall
                }
                newObj.transform.parent = RoomParent.transform;
                newObj.transform.rotation = Quaternion.AngleAxis(d * 60, Vector3.up); // rotate each door so that it goes in the right position. I could use a for loop for this...
                d++;

                hintCanvas.SetActive(false);
                if (getWarning(GameControllerUnity.myCave.getAllConnected(room)) != null)
                {
                    showOnScreen(getWarning(GameControllerUnity.myCave.getAllConnected(room)));
                }

                if (GameControllerUnity.myMap.getHazardsInRoom(room) == Map.Hazards.Pit)
                {
                    encounterPit();
                }
                else if (GameControllerUnity.myMap.getHazardsInRoom(room) == Map.Hazards.Bat)
                {
                    encounterBats();
                }
                else if (GameControllerUnity.myMap.getHazardsInRoom(room) == Map.Hazards.Wumpus)
                {
                    encounterWumpus();
                }
            }

            

            floorObj.transform.position = Vector3.zero; // move the floor parent to the right position
            floorObj.transform.parent = RoomParent.transform;

            RoomParent.transform.position = new Vector3(0, -4.5f, 0);
            RoomParent.transform.localScale = new Vector3(2, 2, 2);

            RoomParent.transform.rotation = Quaternion.AngleAxis(-30 - (direction + 1) * 60, Vector3.up);

            fromArrow = Instantiate(fromArrowPrefab); // set up the blue arrow on the bottom of the level so that the player can see where they came from
            fromArrow.transform.rotation = Quaternion.AngleAxis( 0, Vector3.up);
            fromArrow.transform.parent = RoomParent.transform;
            //arrow.transform.rotation = Quaternion.AngleAxis(-direction * 60, Vector3.forward); 

        }
        

        /// <summary>
        /// You can purchase 2 more arrows by getting at least 2 out of three questions right
        /// </summary>
        public void buyArrow()
        {
            CoinSound.Play();
            GameControllerUnity.myPlayer.setNumberOfTurns(GameControllerUnity.myPlayer.getNumberOfTurns() + 1);
            Debug.Log("Bought an Arrow");
            triviaConsequence = TriviaType.GiveArrow; 
            doMultipleQuestions(2, 3);            
            buyMenuActive = false;
        }

        /// <summary>
        /// You can purchase a secret by getting at least 2 out of 3 trivia questions right.
        /// </summary>
        public void buySecret()
        {
            CoinSound.Play();
            GameControllerUnity.myPlayer.setNumberOfTurns(GameControllerUnity.myPlayer.getNumberOfTurns() + 1);
            Debug.Log("Bought a Secret");
            triviaConsequence = TriviaType.GiveHint;
            doMultipleQuestions(2, 3);
            buyMenuActive = false;
        }

        private int toDir;

        
        // these methods hanle input

        public void moveRight()
        {

            if (canMove && !buyMenuActive && !batsEncounter)
            {
                //Debug.Log("Right");
                //roomAnimator.Play("RoomParentRight");
                direction++;
            }
        }

        public void moveLeft()
        {
            if (canMove && !buyMenuActive && !batsEncounter)
            {
                //Debug.Log("Left");
                //roomAnimator.Play("RoomParentLeft");
                direction--;
            }
        }

        /// <summary>
        /// this checks for the conditions for moving a player forward, and if they can, it plays animations and creates the new room
        /// </summary>
        public void moveForward()
        {
            if (canMove && !buyMenuActive && !batsEncounter)
            {
                Debug.Log("Forward");
                if (walls[direction] == WallStates.Open) // if the wall is open
                {
                    GameControllerUnity.myPlayer.setNumberOfTurns(GameControllerUnity.myPlayer.getNumberOfTurns() + 1); // maybe it couldn't hurt to add increment/decrement method to this?
                    GameControllerUnity.myPlayer.setNumberOfCoins(GameControllerUnity.myPlayer.getNumberOfCoins() + 1); // maybe it couldn't hurt to add increment/decrement method to this?

                    int toRoom = GameControllerUnity.myCave.getRoomNumDirection(room, direction);
                    Debug.Log("Moved from " + room + " to " + toRoom + " " + direction);
                    //cameraAnimator.Play("LeaveRoom");
                    StartCoroutine(animateLeave()); // ooh this looks cool
                    room = toRoom;
                    GameControllerUnity.myMap.setPlayerLocation(room);
                    StepSound.Play();
                    int[] test = GameControllerUnity.myCave.getAllConnected(room);
                }
                else
                {
                    Debug.Log("You can't move there"); // if the wall is closed
                }
            }
        }

        /// <summary>
        /// this handles the animations for when the player moves between rooms
        /// </summary>
        /// <returns></returns>
        IEnumerator animateLeave()
        {
            canMove = false;
            cameraAnimator.Play("LeaveRoom");
            yield return new WaitForSeconds(0.4f);
            destroyRoom(); // destroys the old room 
            createRoom();
            cameraAnimator.Play("EnterRoom");
            yield return new WaitForSeconds(0.5f);
            canMove = true;
        }

        /// <summary>
        /// returns the warnings for the current room.
        /// </summary>
        /// <param name="connectedRooms"></param>
        /// <returns></returns>
        public string getWarning(int[] connectedRooms)
        {
            // this method gives the warnings for hazards in the surrounding rooms
            foreach (int i in connectedRooms)
            {
                if (GameControllerUnity.myMap.getHazardsInRoom(i) == Map.Hazards.Wumpus)
                {
                    Debug.Log(GameControllerUnity.myMap.getWumpusLocation());
                    WumpusSound.Play();
                    return "I smell a Wumpus..."; // to do, have this trigger a sound or something.. that'd be cooool.
                    
                }
            }

            // establishing a priority to the warnings...

            foreach (int i in connectedRooms)
            {
                if (GameControllerUnity.myMap.getHazardsInRoom(i) == Map.Hazards.Bat)
                {
                    BatSound.Play();
                    return "I hear some Bats..."; // to do, have this trigger a sound or something.. that'd be cooool.
                }
            }

            foreach (int i in connectedRooms)
            {
                if (GameControllerUnity.myMap.getHazardsInRoom(i) == Map.Hazards.Pit)
                {
                    WindSound.Play();
                    return "I feel a draft..."; // to do, have this trigger a sound or something.. that'd be cooool.
                }
            }

            return null; // no useful warnings
        }

        /// <summary>
        /// can tell where a bat is, pit is, where the wumpus is, where you are
        /// </summary>
        /// <returns></returns>
        public string getSecret()
        {
            int secretLevel = GameControllerUnity.gen.Next(6);

            switch (secretLevel)
            {
                case 0:
                    return "A bat is located at: " + GameControllerUnity.myMap.getBatLocation()[0];
                case 1:
                    return "A bat is located at: " + GameControllerUnity.myMap.getBatLocation()[1];
                case 2:
                    return "A pit is at: " + GameControllerUnity.myMap.getPitLocation()[0];
                case 3:
                    return "A pit is at: " + GameControllerUnity.myMap.getPitLocation()[1];
                case 4:
                    return "The Wumpus is at: " + GameControllerUnity.myMap.getWumpusLocation();
                case 5:
                    return "You are at: " + GameControllerUnity.myMap.getPlayerLocation();
                default:
                    return "The Wumpus is at " + GameControllerUnity.myMap.getWumpusLocation();
            }
        }

        /// <summary>
        /// checks if the player can fire an arrow, and if the arrow hits, kills the wumpus, or it will make the wumpus flee
        /// </summary>
        public void fireArrow()
        {
            if (canMove && !buyMenuActive && !batsEncounter)
            {
                // To do, have animation system for firing the arrow implemented

                Debug.Log("fire arrow");


                checkFailureState();
                if (walls[direction] == WallStates.Open)
                {
                    Debug.Log("can fire");
                    // can fire arrow
                    GameControllerUnity.myPlayer.setNumberOfTurns(GameControllerUnity.myPlayer.getNumberOfTurns() + 1);
                    ArrowObject.SetActive(false);
                    ArrowObject.SetActive(true);
                    GameControllerUnity.myPlayer.setNumberOfArrows(GameControllerUnity.myPlayer.getNumberOfArrows() - 1);
                    // subtract an arrow
                    Debug.Log(GameControllerUnity.myMap.getHazardsInRoom(GameControllerUnity.myCave.getRoomNumDirection(GameControllerUnity.myMap.getPlayerLocation(), direction)));
                    if (GameControllerUnity.myMap.getHazardsInRoom(GameControllerUnity.myCave.getRoomNumDirection(GameControllerUnity.myMap.getPlayerLocation(), direction)) == Map.Hazards.Wumpus)
                    {
                        killedWumpus = true;
                        gameOverReason.text = "You defeated the Wumpus!";
                        gameOver();
                    }
                    else
                    {
                        checkFailureState();
                        GameControllerUnity.myMap.escapingWumpus(GameControllerUnity.myCave.getAllSurrounding(GameControllerUnity.myMap.getWumpusLocation()));
                    }
                }
            }
        }

        private bool killedWumpus = false;

        /// <summary>
        /// triggers the game over state
        /// </summary>
        public void gameOver()
        {
            
            if (killedWumpus)
            {
                gameOverColor.color = new Color(0, 0.39f, 0);
                gameOverScore.text = "Score: " + (GameControllerUnity.myPlayer.getTotalScore() + 100);
            }
            else
            {
                gameOverColor.color = new Color(0.15f, 0, 0);
                gameOverScore.text = "Score: " + GameControllerUnity.myPlayer.getTotalScore();
            }

            canMove = false;
            //hideTrivia();
            gameOverCanvas.SetActive(true);
            hideTrivia();
        }

        /// <summary>
        /// submits the scores when the game is over
        /// </summary>

        public void submitScore()
        {
            if (killedWumpus)
            {
                GameControllerUnity.myScores.addScore(GameControllerUnity.myPlayer.getTotalScore() + 100, GameControllerUnity.playerName, GameControllerUnity.RandomSeed);
            }
            else
            {
                GameControllerUnity.myScores.addScore(GameControllerUnity.myPlayer.getTotalScore(), GameControllerUnity.playerName, GameControllerUnity.RandomSeed);
            }
            // now that I think about it, player name should be stored in the player class, and the random seed should be stored in the cave class... that would be a better way to do it...
            GameControllerUnity.viewHS();

            
        }

        /// <summary>
        /// sets the name for when the game is over
        /// </summary>
        /// <param name="name"></param>
        public void setName(InputField name)
        {
            GameControllerUnity.playerName = name.text;
        }


        private enum TriviaType { Wumpus, GameOver, GiveHint, GiveArrow }; // used to specify what will happen if the user wins/fails the trivia
        private TriviaType triviaConsequence;

        /// <summary>
        /// Must answer 2/3 questions to get out of the pit and continue playing
        /// </summary>
        public void encounterPit()
        {
            Debug.Log("Player encountered pit");
            triviaConsequence = TriviaType.GameOver;
            doMultipleQuestions(2, 3);
        }

        /// <summary>
        /// plays the animations and moves the player to a different room
        /// </summary>
        public void encounterBats()
        {
            canMove = false;
            //cameraAnimator["BatPickup"].wrapMode = WrapMode.Once;
            //cameraAnimator.Play("BatPickup");
            //BatObject.GetComponent<Animator>().Play("FlyOut");
            Debug.Log("Player encountered bats");
            // have some sort of animation, and perhaps a pop-up
            GameControllerUnity.myMap.GeneratePlayerPosition(); // generates a new position for the player
            room = GameControllerUnity.myMap.getPlayerLocation(); //todo replace room w/ this
            // I'm going to have an animation that has the player see the bats and have them be taken away by them
            StartCoroutine(animateBats());
                      
            //cameraAnimator.Play("BatPlace");
            
            GameControllerUnity.myMap.GenerateBats();

            Debug.Log("Player new position" + GameControllerUnity.myMap.getPlayerLocation());
        }

        private bool batsEncounter = false;
        /// <summary>
        /// handles the animations for the bat encounter
        /// </summary>
        /// <returns></returns>
        /// 
        IEnumerator animateBats()
        {
            batsEncounter = true;
            canMove = false;
            BatObject.SetActive(true);
            BatAnim.Play("FlyIn");
            yield return new WaitForSeconds(1.5f);
            cameraAnimator.Play("BatPickup");
            BatAnim.Play("FlyOut");
            yield return new WaitForSeconds(1.5f);
            destroyRoom();
            createRoom();
            cameraAnimator.Play("BatPlace");
            //canMove = true;
            batsEncounter = false;
        }
        
        /// <summary>
        /// same room as wumpus, must fight the wumpus
        /// </summary>
        public void encounterWumpus()
        {
            Debug.Log("Player encountered wumpus");
            WumpusObject.SetActive(true);
            WumpusObject.GetComponent<Animator>().Play("Encounter"); // this animation actually plays by default
            // have some sort of animations and stuff
            triviaConsequence = TriviaType.Wumpus;
            doMultipleQuestions(3, 5);
        }

        
        /// <summary>
        /// checks if the player has lost
        /// </summary>
        /// <returns></returns>
        public bool checkFailureState()
        {
            if (GameControllerUnity.myPlayer.getNumberOfCoins() < 0)
            {
                gameOverReason.text = "You ran out of coins!";
                gameOver();
                return true;
            }
            else if (GameControllerUnity.myPlayer.getNumberOfArrows() <= 0)
            {
                gameOverReason.text = "You ran out of arrows!";
                gameOver();
                return true;
            }
            return false;
        }

        public Text triviaTitle;
        public Text[] triviaAnswers;


        /// <summary>
        /// starts a trivia question
        /// </summary>
        public void doTrivia()
        {
            inTrivia = true;
            canMove = false;
            triviaCanvas.SetActive(true);
            GameControllerUnity.myPlayer.setNumberOfCoins(GameControllerUnity.myPlayer.getNumberOfCoins() - 1);
            if (checkFailureState())
            {
                hideTrivia();
                return;
            }
            // todo set up animations
            GameControllerUnity.myTrivia.pickQuestion();
            //Text myTitle = GameObject.FindGameObjectWithTag("Text_Question").GetComponent<Text>();

            triviaTitle.text = GameControllerUnity.myTrivia.getQuestion();
            //GameObject[] myA = GameObject.FindGameObjectsWithTag("Text_Answer");
            Text[] myAnswers = new Text[4];
            string[] answers = GameControllerUnity.myTrivia.getAnswers();

            for (int i = 0; i < triviaAnswers.Length; i++)
            {
                myAnswers[i] = triviaAnswers[i].GetComponent<Text>();
                myAnswers[i].text = answers[i];

            }
        }

        private int numberCorrect = 0;
        private int numberFalse = 0;
        private int numberMin = 0;
        private int numberTotal = 0;

        /// <summary>
        /// sets up trivia for doing multiple questions, with a certain amount that have to be correct
        /// </summary>
        /// <param name="min"></param>
        /// <param name="total"></param>
        public void doMultipleQuestions(int min, int total)
        {
            hasTriviaRemaining = true;
            numberMin = min;
            numberTotal = total;
            numberCorrect = 0;
            numberFalse = 0;


        }

        public void hideTrivia()
        {
            // animation to hide the panel
            inTrivia = false;
            canMove = true;
            triviaCanvas.SetActive(false);
        }

        private DateTime answerTimer;
        private float showAnswerTime = 2.0f;
        
        /// <summary>
        /// handles the answer being chosen
        /// </summary>
        /// <param name="ans"></param>
        public void getAnswer(int ans)
        {
            CorrectText.SetActive(false);
            IncorrectText.SetActive(false);

            answerTimer = DateTime.Now;
            Debug.Log("You chose answer: " + ans);
            if (GameControllerUnity.myTrivia.isCorrect(ans))
            {
                Debug.Log("Correct");
                CorrectText.SetActive(true);
                numberCorrect++;
            }
            else
            {
                Debug.Log("Incorrect");
                IncorrectText.SetActive(true);
                numberFalse++;
            }
            Debug.Log(numberMin);
            Debug.Log(numberTotal);
            Debug.Log(numberCorrect);
            Debug.Log(numberFalse);

            hideTrivia();
        }

        public void displayHint()
        {
            showOnScreen(getSecret());
        }

        private float threshold = 0.05f;

        /// <summary>
        /// rotates the room to match the direction, so that turning has a smooth animation
        /// </summary>
        void rotateRoom()
        {
            float rotSpeed = 0.05f;
            float rotTolerance = 2.5f;
            float roomRot = RoomParent.transform.localEulerAngles.y;
            float destinationRot = (-30 - (direction + 1) * 60) + 360;
            if (direction == 5)
            {
                destinationRot = 330;
            }

            if ((direction < 5 && direction > 1) && roomRot > 325)
            {
                RoomParent.transform.RotateAround(Vector3.up, rotSpeed ); // rot speed should have time.deltatime, however that has caused shaking because it doesn't always take the same amount of frames to rotate. it matters because my desktop computer runs this at 170 fps
            }
            else if (direction == 5 && roomRot < 35)
            {
                RoomParent.transform.RotateAround(Vector3.up, -rotSpeed ); 
            }
            else
            {
                if (roomRot + rotTolerance < destinationRot)
                {
                    RoomParent.transform.RotateAround(Vector3.up, rotSpeed ); // this prevents the camera from shaking around
                }
                else if (roomRot - rotTolerance > destinationRot)
                {
                    RoomParent.transform.RotateAround(Vector3.up, -rotSpeed );
                }
            }
        }
        
        public void toggleBuyMenu()
        {
            if (canMove)
            {
                buyMenuActive = !buyMenuActive; // toggles the buy menu

            }
        }

        private DateTime debounce = DateTime.Now;

        // this handles inptu and stuff that happens without direct user input
        void Update()
        {
            if (gameOverCanvas.active)
            {
                canMove = false;
            }

            rotateRoom();
            //RoomParent.transform.rotation = Quaternion.AngleAxis(-30 - (direction + 1) * 60, Vector3.up);

            if (CorrectText.active || IncorrectText.active)
            {
                if (DateTime.Now.Second - answerTimer.Second > showAnswerTime)
                {
                    CorrectText.SetActive(false);
                    IncorrectText.SetActive(false);
                }
            }

            if (hintCanvas.active)
            {
                if (DateTime.Now.Second - onScreenTimer.Second > onScreenLength)
                {
                    hintCanvas.SetActive(false);
                }
            }


            // this handles the trivia stuff
            if (!gameOverCanvas.active)
            {
                if (hasTriviaRemaining && !inTrivia)
                {
                    // this whole section could be redone to make it look better
                    if (numberCorrect < numberMin && numberCorrect + numberFalse < numberTotal && numberFalse <= numberTotal - numberMin)
                    {
                        doTrivia();
                    }
                    else if (numberCorrect >= numberMin)
                    {
                        // this is the trivia's win state
                        hasTriviaRemaining = false;
                        numberCorrect = 0;
                        numberFalse = 0;
                        numberMin = 0;
                        numberTotal = 0;

                        if (triviaConsequence == TriviaType.Wumpus)
                        {
                            Debug.Log("The wumpus has fled");
                            WumpusObject.GetComponent<Animator>().Play("Escape");
                            for (int i = GameControllerUnity.gen.Next(2) + 2; i > 0; i--)
                            {
                                GameControllerUnity.myMap.escapingWumpus(GameControllerUnity.myCave.getAllSurrounding(GameControllerUnity.myMap.getWumpusLocation()));
                            }
                        }
                        else if (triviaConsequence == TriviaType.GiveArrow)
                        {
                            GameControllerUnity.myPlayer.setNumberOfArrows(GameControllerUnity.myPlayer.getNumberOfArrows() + 2);
                        }
                        else if (triviaConsequence == TriviaType.GiveHint)
                        {
                            displayHint();   
                        }
                    }
                    else if ((numberFalse > (numberTotal - numberMin)) || numberFalse + numberCorrect > numberTotal)
                    {
                        //trivia fail state
                        if (triviaConsequence == TriviaType.Wumpus)
                        {
                            WumpusObject.GetComponent<Animator>().Play("Eat");
                            gameOverReason.text = "You were devoured by the hungry Wumpus."; // You are likely to be eaten by a Grue.
                            gameOver();
                        }
                        else if (triviaConsequence == TriviaType.GameOver)
                        {
                            gameOverReason.text = "You tripped over a stray shoelace and fell to your death";
                            gameOver();
                        }
                    }
                }
            }
            


            GUIArrows.text = "" + GameControllerUnity.myPlayer.getNumberOfArrows();
            GUICoins.text = "" + GameControllerUnity.myPlayer.getNumberOfCoins();
            GUITurns.text = "Turns: " + GameControllerUnity.myPlayer.getNumberOfTurns(); // to do find a neater/better way of doing this. maybe just .ToString()?

            buyMenu.SetActive(buyMenuActive);
            //RoomParent.transform.rotation = Quaternion.AngleAxis(-30 - (direction + 1) * 60, Vector3.up);
            //arrow.transform.rotation = Quaternion.AngleAxis(-direction * 60, Vector3.forward);
            
            direction %= 6;
            if (direction < 0)
            {
                direction += 6;
            }
            if (direction > 5 || direction < 0)
            {
                direction = 3;
            }
            int toRoom = GameControllerUnity.myCave.getRoomNumDirection(room, direction);
            infoText.text = "Current Room: " + room + "\nDirection: " + direction + "\nDestination: " + toRoom;

            // KEYBOARD CONTROLS
            if (Input.GetKey(KeyCode.LeftAlt))
            {
                // these are just cheat codes... every game should have cheat codes.
                if (Input.GetKeyDown("1"))
                {
                    killedWumpus = true;
                    showOnScreen("Wumpus Slayer");
                }
                else if (Input.GetKeyDown("2"))
                {
                    gameOverReason.text = "Hey look, you discovered my cheat codes!";
                    gameOver();
                }
                else if (Input.GetKeyDown("3"))
                {
                    showOnScreen("Rolling in the Dosh!");
                    GameControllerUnity.myPlayer.setNumberOfCoins(GameControllerUnity.myPlayer.getNumberOfCoins() + 1000);
                    GameControllerUnity.myPlayer.setNumberOfArrows(GameControllerUnity.myPlayer.getNumberOfArrows() + 1000);
                }
                else if (Input.GetKeyDown("4"))
                {
                    showOnScreen("Away we go...");
                    encounterBats();
                }
            }
            else if (Input.GetKeyDown("w"))
            {
                // forward
                moveForward();
            }
            else if (Input.GetKeyDown("a")) // do it this way so that we can use an xbox 360 controller
            {
                // left
                moveLeft();
            }
            else if (Input.GetKeyDown("d"))
            {
                // right
                moveRight();
            }
            else if (Input.GetKeyDown("b"))
            {
                // open the buy menu
                toggleBuyMenu();
            }
            else if (Input.GetKeyDown("e"))
            {
                fireArrow();
            }
            else if (Input.GetKeyDown("1"))
            {
                // buy an arrow in the buy menu
                if (buyMenuActive)
                {
                    // buy arrow
                    buyArrow();
                }
                else if (triviaCanvas.active)
                {
                    getAnswer(0);
                }
            }
            else if (Input.GetKeyDown("2"))
            {
                // buy a secret in the buy menu
                if (buyMenuActive)
                {
                    // buy secret
                    buySecret();
                }
                else if (triviaCanvas.active)
                {
                    getAnswer(1);
                }
            }
            else if (Input.GetKeyDown("3"))
            {
                if (triviaCanvas.active)
                {
                    getAnswer(2);
                }
            }
            else if (Input.GetKeyDown("4"))
            {
                if (triviaCanvas.active)
                {
                    getAnswer(3);
                }
            }
            else if (Input.GetKeyDown(KeyCode.Escape))
            {
                GameControllerUnity.titleS();
            }

            // XBOX 360 CONTROLS
            if (Input.GetAxis("Cheat Button") > 0.5f)
            {
                // these are just cheat codes... every game should have cheat codes.
                if (Input.GetAxis("B1") > 0.5f)
                {
                    killedWumpus = true;
                    showOnScreen("Wumpus Slayer");
                    debounce = DateTime.Now;
                }
                else if (Input.GetAxis("B2") > 0.5f)
                {
                    gameOverReason.text = "Hey look, you discovered my cheat codes!";
                    gameOver();
                    debounce = DateTime.Now;
                }
                else if (Input.GetAxis("B3") > 0.5f)
                {
                    showOnScreen("Rolling in the Dosh!");
                    GameControllerUnity.myPlayer.setNumberOfCoins(GameControllerUnity.myPlayer.getNumberOfCoins() + 1000);
                    GameControllerUnity.myPlayer.setNumberOfArrows(GameControllerUnity.myPlayer.getNumberOfArrows() + 1000);
                    debounce = DateTime.Now;
                }
                else if (Input.GetAxis("FireArrow") > 0.5f)
                {
                    showOnScreen("Away we go...");
                    encounterBats();
                    debounce = DateTime.Now;
                }
            }
            else if (!gameOverCanvas.active && DateTime.Now.Subtract(debounce).TotalMilliseconds > 250) // need to debounce for the analog stick
            {
                if (Input.GetAxis("Vertical") < -0.5f)
                {
                    // forward
                    moveForward();
                    debounce = DateTime.Now;
                }
                else if (Input.GetAxis("Horizontal") < -0.5f) // do it this way so that we can use an xbox 360 controller
                {
                    // left
                    moveLeft();
                    debounce = DateTime.Now;
                }
                else if (Input.GetAxis("Horizontal") > 0.5f)
                {
                    // right
                    moveRight();
                    debounce = DateTime.Now;
                }
                else if (Input.GetAxis("Buy") > 0.5f)
                {
                    // open the buy menu
                    toggleBuyMenu();
                    debounce = DateTime.Now;
                }
                else if (Input.GetAxis("FireArrow") > 0.5f)
                {
                    fireArrow();
                    debounce = DateTime.Now;
                }
                else if (Input.GetAxis("B1") > 0.5f)
                {
                    // buy an arrow in the buy menu
                    if (buyMenuActive)
                    {
                        // buy arrow
                        buyArrow();
                        debounce = DateTime.Now;
                    }
                    else if (triviaCanvas.active)
                    {
                        getAnswer(0);
                        debounce = DateTime.Now;
                    }
                }
                else if (Input.GetAxis("B2") > 0.5f)
                {
                    // buy a secret in the buy menu
                    if (buyMenuActive)
                    {
                        // buy secret
                        buySecret();
                        debounce = DateTime.Now;
                    }
                    else if (triviaCanvas.active)
                    {
                        getAnswer(1);
                        debounce = DateTime.Now;
                    }
                }
                else if (Input.GetAxis("B3") > 0.5f)
                {
                    if (triviaCanvas.active)
                    {
                        getAnswer(2);
                        debounce = DateTime.Now;
                    }
                }
                else if (Input.GetAxis("B4") > 0.5f)
                {
                    if (triviaCanvas.active)
                    {
                        getAnswer(3);
                        debounce = DateTime.Now;
                    }
                }
                else if (Input.GetAxis("Quit") > 0.5f)
                {
                    GameControllerUnity.titleS();
                    debounce = DateTime.Now;
                }
            }
        }
    }

}