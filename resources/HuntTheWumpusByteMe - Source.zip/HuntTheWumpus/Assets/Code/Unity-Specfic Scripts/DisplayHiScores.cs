﻿using UnityEngine;
using System.Collections.Generic;
using System.Collections;
using UnityEngine.UI;
using System;

namespace WumpusCombinedBuild
{
    public class DisplayHiScores : MonoBehaviour
    {
        // this class handles the HiScores scene, which is used to display all of the high scores

        // I need to add seeds to the display
        public GameObject templateScore;
        public GameObject ScoresParent;

        public float y_offset = 45.0f;
        public float yStart = 450.0f;

        public Color FirstPlace = new Color(255,215,0);
        public Color SecondPlace = new Color(192,192,192);
        public Color ThirdPlace = new Color(205,127,50);
        public Color LoserPlace = new Color(255,0,0);

        // Use this for initialization
        void Start()
        {
            if (GameControllerUnity.myScores == null)
            {
                Debug.Log("This shouldn't happen.");
                GameControllerUnity.myScores = new HighScore();

                GameControllerUnity.myScores.addScore(1337000, "Chris is the coolest.", -1);
                GameControllerUnity.myScores.addScore(1336000, "This isn't done yet.", -1);

            }
            displayScores();
        }

        void Update()
        {
            if (Input.GetAxis("Start") > 0.5f)
            {
                toTitleScreen();
            }
        }

        public void toTitleScreen()
        {
            GameControllerUnity.titleS();
        }

        /// <summary>
        /// gets all of the scores and displays them
        /// </summary>
        void displayScores()
        {
            List<int> numericScores = GameControllerUnity.myScores.getScoreInt();
            List<string> nameScores = GameControllerUnity.myScores.getScoreString();

            for (int i = numericScores.Count - 1; i >= 0; i--)
            {
                Debug.Log(i);
                GameObject currentPanel;
                currentPanel = Instantiate(templateScore);
                currentPanel.name = "Panel" + i;
                currentPanel.transform.parent = ScoresParent.transform;
               
                RectTransform position = currentPanel.GetComponent<RectTransform>();

                position.anchoredPosition = new Vector2(0, (y_offset  * i) - yStart);

                GameObject nameObj = GameObject.Find("/Main Camera/HiScoreCanvas/ScoresParent/" + "Panel" + i + "/" + "Name"); 
                GameObject scoreObj = GameObject.Find("/Main Camera/HiScoreCanvas/ScoresParent/" + "Panel" + i + "/" + "Score");

                Text name = nameObj.GetComponent<Text>();
                Text score = scoreObj.GetComponent<Text>();

                name.text = nameScores[i];
                score.text = numericScores[i].ToString();

                Debug.Log(nameScores[i] + " " + numericScores[i].ToString());

                Image image = currentPanel.GetComponent<Image>();

                if (i == numericScores.Count - 1)
                {
                    // first
                    image.color = FirstPlace;
                }
                else if (i == numericScores.Count - 2)
                {
                    image.color = SecondPlace;
                }
                else if (i == numericScores.Count - 3)
                {
                    image.color = ThirdPlace;
                }
                else
                {
                    image.color = LoserPlace;
                }

                // I planned on having animations that would active when each of the scores are added, but I think this will do for now
            }


        }
    }
}

